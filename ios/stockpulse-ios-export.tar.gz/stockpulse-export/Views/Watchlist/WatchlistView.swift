// Views/Watchlist/WatchlistView.swift
import SwiftUI
import Charts

struct WatchlistView: View {
    @Environment(RippleViewModel.self) private var vm
    @State private var selectedTicker: String?

    var body: some View {
        NavigationStack {
            List {
                ForEach(vm.allTickers, id: \.self) { ticker in
                    WatchRowView(ticker: ticker, selectedTicker: $selectedTicker)
                        .listRowBackground(selectedTicker == ticker ? Color.blue.opacity(0.08) : Color.clear)
                        .listRowSeparatorTint(.secondary.opacity(0.2))
                }
            }
            .listStyle(.plain)
            .navigationTitle("Watchlist")
            .refreshable { await vm.loadAll() }
            .safeAreaInset(edge: .top) {
                if let ticker = selectedTicker {
                    StockDetailBanner(ticker: ticker) { selectedTicker = nil }
                        .transition(.move(edge: .top).combined(with: .opacity))
                }
            }
            .animation(.spring(response: 0.3), value: selectedTicker)
        }
    }
}

// MARK: - Watch Row

struct WatchRowView: View {
    let ticker: String
    @Binding var selectedTicker: String?
    @Environment(RippleViewModel.self) private var vm

    var body: some View {
        let stats = vm.stats(for: ticker)
        let normalized = vm.normalizedHistory(for: ticker)
        let rippleBadges = vm.rippleBadges(for: ticker)
        let isSelected = selectedTicker == ticker

        Button {
            withAnimation { selectedTicker = isSelected ? nil : ticker }
        } label: {
            HStack(spacing: 12) {
                // Ticker + name
                VStack(alignment: .leading, spacing: 2) {
                    Text(ticker)
                        .font(.system(size: 14, weight: .bold, design: .monospaced))
                    if !rippleBadges.isEmpty {
                        HStack(spacing: 4) {
                            ForEach(rippleBadges, id: \.catalystTicker) { badge in
                                HStack(spacing: 2) {
                                    Image(systemName: badge.verdict.icon)
                                        .font(.system(size: 8))
                                    Text("↑\(badge.catalystTicker)")
                                        .font(.system(size: 9, weight: .semibold, design: .monospaced))
                                }
                                .foregroundStyle(verdictColor(badge.verdict))
                                .padding(.horizontal, 5)
                                .padding(.vertical, 2)
                                .background(verdictColor(badge.verdict).opacity(0.1))
                                .clipShape(RoundedRectangle(cornerRadius: 3))
                            }
                        }
                    }
                }
                .frame(width: 80, alignment: .leading)

                // Price + changes
                VStack(alignment: .trailing, spacing: 2) {
                    Text(String(format: "$%.2f", stats.price))
                        .font(.system(size: 13, weight: .semibold, design: .monospaced))
                    Text(String(format: "%+.2f%%", stats.change1D))
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundStyle(stats.change1D >= 0 ? .green : .red)
                }
                .frame(width: 72, alignment: .trailing)

                // Sparkline
                SparklineView(
                    data: normalized,
                    color: stats.change30D >= 0 ? .green : .red,
                    showArea: true,
                    height: 34
                )
                .frame(width: 80)

                // 30D change
                Text(String(format: "%+.1f%%", stats.change30D))
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundStyle(stats.change30D >= 0 ? .green : .red)
                    .frame(width: 52, alignment: .trailing)
            }
            .padding(.vertical, 6)
        }
        .foregroundStyle(.primary)
    }

    func verdictColor(_ v: RippleVerdict) -> Color {
        switch v {
        case .confirmed: return .green
        case .forming:   return .orange
        case .failed:    return .red
        case .watching:  return .blue
        }
    }
}

// MARK: - Stock Detail Banner

struct StockDetailBanner: View {
    let ticker: String
    let onClose: () -> Void
    @Environment(RippleViewModel.self) private var vm

    var body: some View {
        let stats = vm.stats(for: ticker)
        let normalized = vm.normalizedHistory(for: ticker)
        let history = vm.histories[ticker] ?? []
        let sorted = history.sorted { $0.date < $1.date }

        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(ticker)
                        .font(.system(size: 22, weight: .bold, design: .monospaced))
                    Text(String(format: "$%.2f", stats.price))
                        .font(.system(size: 17, design: .monospaced))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Button(action: onClose) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.secondary)
                        .font(.title2)
                }
            }

            // Stat grid
            HStack(spacing: 8) {
                StatCard(label: "1D", value: String(format: "%+.2f%%", stats.change1D),
                         valueColor: stats.change1D >= 0 ? .green : .red)
                StatCard(label: "30D", value: String(format: "%+.1f%%", stats.change30D),
                         valueColor: stats.change30D >= 0 ? .green : .red)
                StatCard(label: "High", value: String(format: "$%.2f", sorted.map(\.high).max() ?? 0))
                StatCard(label: "Low",  value: String(format: "$%.2f", sorted.map(\.low).min() ?? 0))
            }

            // 30-day chart
            Chart {
                ForEach(Array(normalized.enumerated()), id: \.offset) { _, pt in
                    AreaMark(x: .value("Date", pt.date), yStart: .value("Zero", 0), yEnd: .value("Chg", pt.pctChange))
                        .foregroundStyle((stats.change30D >= 0 ? Color.green : Color.red).opacity(0.08))
                    LineMark(x: .value("Date", pt.date), y: .value("Chg", pt.pctChange))
                        .foregroundStyle(stats.change30D >= 0 ? Color.green : Color.red)
                }
            }
            .chartYAxis { AxisMarks(format: .percent.scale(0.01)) }
            .frame(height: 100)

            // Ripple memberships
            let badges = vm.rippleBadges(for: ticker)
            if !badges.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(badges, id: \.catalystTicker) { badge in
                            VerdictBadge(verdict: badge.verdict)
                            Text("of \(badge.catalystTicker)")
                                .font(.system(size: 11, design: .monospaced))
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .padding()
        .background(.regularMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .shadow(radius: 8)
        .padding(.horizontal)
    }
}

// MARK: - AI Analyst View

struct AIAnalystView: View {
    @Environment(RippleViewModel.self) private var vm
    @FocusState private var focused: Bool

    let quickQuestions = [
        "Did SPCX actually lift RKLB?",
        "Which ripple confirmed most strongly?",
        "Which ripple failed to materialize?",
        "Is it too late to buy ASTS?",
        "Compare NVDA and SPCX ripple strength",
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {

                    // Context badge
                    HStack {
                        Image(systemName: "brain.head.profile")
                            .foregroundStyle(.blue)
                        Text("30-day history + ripple verdicts loaded")
                            .font(.system(size: 12, design: .monospaced))
                            .foregroundStyle(.secondary)
                        Spacer()
                        Circle().fill(.green).frame(width: 6, height: 6)
                        Text("Live").font(.system(size: 11, design: .monospaced)).foregroundStyle(.green)
                    }
                    .padding(10)
                    .background(Color(.systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 8))

                    // Quick questions
                    VStack(alignment: .leading, spacing: 8) {
                        Text("QUICK QUESTIONS")
                            .font(.system(size: 10, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.secondary)
                            .tracking(1)

                        FlowLayout(spacing: 8) {
                            ForEach(quickQuestions, id: \.self) { q in
                                Button(q) {
                                    vm.aiQuery = q
                                    Task { await vm.askAI() }
                                }
                                .font(.system(size: 12))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(Color(.systemGray6))
                                .clipShape(RoundedRectangle(cornerRadius: 6))
                                .foregroundStyle(.secondary)
                            }
                        }
                    }

                    // Input
                    @Bindable var bindVm = vm
                    HStack(alignment: .bottom, spacing: 8) {
                        TextField("Ask about ripples, trends, timing...", text: $bindVm.aiQuery, axis: .vertical)
                            .textFieldStyle(.plain)
                            .lineLimit(3)
                            .focused($focused)
                            .padding(10)
                            .background(Color(.systemGray6))
                            .clipShape(RoundedRectangle(cornerRadius: 10))

                        Button {
                            focused = false
                            Task { await vm.askAI() }
                        } label: {
                            Image(systemName: vm.aiLoading ? "arrow.triangle.2.circlepath" : "arrow.up.circle.fill")
                                .font(.title2)
                                .foregroundStyle(vm.aiQuery.isEmpty ? .secondary : .blue)
                        }
                        .disabled(vm.aiQuery.isEmpty || vm.aiLoading)
                    }

                    // Response
                    if !vm.aiResponse.isEmpty {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("ANALYSIS")
                                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                                .foregroundStyle(.secondary)
                                .tracking(1)
                            Text(vm.aiResponse)
                                .font(.body)
                                .foregroundStyle(.primary)
                        }
                        .padding(14)
                        .background(Color.blue.opacity(0.06))
                        .overlay(alignment: .leading) {
                            Rectangle().fill(Color.blue).frame(width: 3)
                                .clipShape(RoundedRectangle(cornerRadius: 1.5))
                        }
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }

                    if vm.aiLoading {
                        HStack {
                            ProgressView()
                            Text("Analyzing...").font(.footnote).foregroundStyle(.secondary)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("AI Analyst")
        }
    }
}

// MARK: - Simple flow layout for chips

struct FlowLayout: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let rows = computeRows(proposal: proposal, subviews: subviews)
        let height = rows.map { $0.map { $0.sizeThatFits(.unspecified).height }.max() ?? 0 }.reduce(0) { $0 + $1 + spacing }
        return CGSize(width: proposal.width ?? 0, height: max(0, height - spacing))
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let rows = computeRows(proposal: proposal, subviews: subviews)
        var y = bounds.minY
        for row in rows {
            var x = bounds.minX
            let rowHeight = row.map { $0.sizeThatFits(.unspecified).height }.max() ?? 0
            for subview in row {
                let size = subview.sizeThatFits(.unspecified)
                subview.place(at: CGPoint(x: x, y: y), proposal: ProposedViewSize(size))
                x += size.width + spacing
            }
            y += rowHeight + spacing
        }
    }

    private func computeRows(proposal: ProposedViewSize, subviews: Subviews) -> [[LayoutSubview]] {
        var rows: [[LayoutSubview]] = [[]]
        var currentWidth: CGFloat = 0
        let maxWidth = proposal.width ?? .infinity
        for subview in subviews {
            let size = subview.sizeThatFits(.unspecified)
            if currentWidth + size.width > maxWidth && !rows[rows.count - 1].isEmpty {
                rows.append([])
                currentWidth = 0
            }
            rows[rows.count - 1].append(subview)
            currentWidth += size.width + spacing
        }
        return rows
    }
}
