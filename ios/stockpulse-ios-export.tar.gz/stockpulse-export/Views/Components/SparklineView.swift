// Views/Components/SparklineView.swift
import SwiftUI
import Charts

struct SparklineView: View {
    let data: [(date: Date, pctChange: Double)]
    var color: Color = .blue
    var showArea: Bool = false
    var eventDate: Date? = nil
    var height: CGFloat = 36

    private var isPositive: Bool {
        (data.last?.pctChange ?? 0) >= 0
    }

    var body: some View {
        Chart {
            if showArea {
                AreaMark(
                    x: .value("Date", data.first?.date ?? Date()),
                    yStart: .value("Zero", 0),
                    yEnd: .value("Change", data.first?.pctChange ?? 0)
                )
                .foregroundStyle(color.opacity(0.08))
            }

            ForEach(Array(data.enumerated()), id: \.offset) { _, point in
                LineMark(
                    x: .value("Date", point.date),
                    y: .value("Change", point.pctChange)
                )
                .foregroundStyle(color)
                .lineStyle(StrokeStyle(lineWidth: 1.5))

                if showArea {
                    AreaMark(
                        x: .value("Date", point.date),
                        yStart: .value("Zero", 0),
                        yEnd: .value("Change", point.pctChange)
                    )
                    .foregroundStyle(color.opacity(0.08))
                }
            }

            if let eventDate {
                RuleMark(x: .value("Event", eventDate))
                    .foregroundStyle(Color.orange.opacity(0.7))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [2, 2]))
            }
        }
        .chartXAxis(.hidden)
        .chartYAxis(.hidden)
        .chartLegend(.hidden)
        .frame(height: height)
    }
}

// MARK: - Verdict Badge

struct VerdictBadge: View {
    let verdict: RippleVerdict

    var color: Color {
        switch verdict {
        case .confirmed: return .green
        case .forming:   return .orange
        case .failed:    return .red
        case .watching:  return .blue
        }
    }

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: verdict.icon)
                .font(.system(size: 10, weight: .bold))
            Text(verdict.rawValue)
                .font(.system(size: 10, weight: .bold, design: .monospaced))
        }
        .foregroundStyle(color)
        .padding(.horizontal, 8)
        .padding(.vertical, 3)
        .background(color.opacity(0.12))
        .clipShape(RoundedRectangle(cornerRadius: 4))
    }
}

// MARK: - Stat Card

struct StatCard: View {
    let label: String
    let value: String
    var valueColor: Color = .primary

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label)
                .font(.system(size: 9, weight: .semibold, design: .monospaced))
                .foregroundStyle(.secondary)
                .textCase(.uppercase)
                .tracking(0.5)
            Text(value)
                .font(.system(size: 14, weight: .bold, design: .monospaced))
                .foregroundStyle(valueColor)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
}
