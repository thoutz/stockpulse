// Views/Ripple/RippleTrackerView.swift
import SwiftUI
import Charts

struct RippleTrackerView: View {
    @Environment(RippleViewModel.self) private var vm
    @State private var expandedRipple: String?

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {

                    // Catalyst selector
                    CatalystSelectorView()

                    // Normalized trend chart — catalyst + all ripples
                    TrendChartCard(
                        catalyst: vm.selectedCatalyst,
                        histories: vm.histories
                    )

                    // Ripple verdict cards
                    VStack(alignment: .leading, spacing: 8) {
                        Text("RIPPLE VERIFICATION")
                            .font(.system(size: 10, weight: .semibold, design: .monospaced))
                            .foregroundStyle(.secondary)
                            .tracking(1)

                        ForEach(vm.currentRippleResults) { result in
                            RippleCardView(
                                result: result,
                                catalyst: vm.selectedCatalyst,
                                histories: vm.histories,
                                isExpanded: expandedRipple == result.rippleTicker
                            ) {
                                withAnimation(.spring(response: 0.3)) {
                                    expandedRipple = expandedRipple == result.rippleTicker ? nil : result.rippleTicker
                                }
                            }
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.vertical)
            }
            .background(Color(.systemBackground))
            .navigationTitle("Ripple Tracker")
            .navigationBarTitleDisplayMode(.large)
            .refreshable { await vm.loadAll() }
            .overlay {
                if vm.isLoading && vm.histories.isEmpty {
                    ProgressView("Loading market data...")
                }
            }
        }
    }
}

// MARK: - Catalyst Selector

struct CatalystSelectorView: View {
    @Environment(RippleViewModel.self) private var vm

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(Array(vm.catalysts.enumerated()), id: \.element.id) { idx, catalyst in
                    let isSelected = vm.selectedCatalystIndex == idx
                    let stats = vm.stats(for: catalyst.ticker)
                    let postChange = vm.histories[catalyst.ticker].map { h in
                        let sorted = h.sorted { $0.date < $1.date }
                        guard let eventIdx = sorted.firstIndex(where: { $0.date >= catalyst.eventDate }),
                              let last = sorted.last else { return 0.0 }
                        return ((last.close - sorted[eventIdx].close) / sorted[eventIdx].close) * 100
                    } ?? 0.0

                    Button {
                        withAnimation { vm.selectedCatalystIndex = idx }
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            HStack {
                                Text(catalyst.ticker)
                                    .font(.system(size: 15, weight: .bold, design: .monospaced))
                                Spacer()
                                Text(String(format: "%+.1f%%", postChange))
                                    .font(.system(size: 12, weight: .semibold, design: .monospaced))
                                    .foregroundStyle(postChange >= 0 ? .green : .red)
                            }
                            Text(catalyst.eventName)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Text("\(catalyst.ripples.count) ripple stocks")
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundStyle(.tertiary)
                        }
                        .padding(12)
                        .frame(width: 200)
                        .background(isSelected ? Color.blue.opacity(0.12) : Color(.systemGray6))
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(isSelected ? Color.blue : Color.clear, lineWidth: 1)
                        )
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                    .foregroundStyle(.primary)
                }
            }
            .padding(.horizontal)
        }
    }
}

// MARK: - Trend Chart Card

struct TrendChartCard: View {
    let catalyst: Catalyst
    let histories: [String: [HistoryPoint]]

    private let colors: [Color] = [.orange, .green, .blue, .purple, .pink, .teal]

    private var tickers: [String] {
        [catalyst.ticker] + catalyst.ripples.map(\.rippleTicker)
    }

    private var baseline: Date {
        // Find earliest date across all histories
        tickers.compactMap { histories[$0]?.sorted { $0.date < $1.date }.first?.date }.min() ?? Date()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("NORMALIZED PERFORMANCE")
                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                .foregroundStyle(.secondary)
                .tracking(1)

            Chart {
                // Event markers
                ForEach(catalyst.events) { event in
                    RuleMark(x: .value("Event", event.date))
                        .foregroundStyle(Color.orange.opacity(0.6))
                        .lineStyle(StrokeStyle(lineWidth: 1, dash: [3, 3]))
                        .annotation(position: .top, alignment: .leading) {
                            Text(event.label)
                                .font(.system(size: 8, design: .monospaced))
                                .foregroundStyle(.orange)
                        }
                }

                // Zero line
                RuleMark(y: .value("Zero", 0))
                    .foregroundStyle(Color.secondary.opacity(0.3))
                    .lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 4]))

                // Stock lines
                ForEach(Array(tickers.enumerated()), id: \.offset) { idx, ticker in
                    let normalized = RippleEngine.normalize(
                        history: histories[ticker] ?? [],
                        from: baseline
                    )
                    let color = colors[min(idx, colors.count - 1)]
                    ForEach(Array(normalized.enumerated()), id: \.offset) { _, pt in
                        LineMark(
                            x: .value("Date", pt.date),
                            y: .value("Change", pt.pctChange),
                            series: .value("Ticker", ticker)
                        )
                        .foregroundStyle(color)
                        .lineStyle(StrokeStyle(lineWidth: idx == 0 ? 2.5 : 1.5))
                    }
                }
            }
            .chartYAxis {
                AxisMarks(format: .percent.scale(0.01))
            }
            .frame(height: 200)

            // Legend
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 80))], spacing: 6) {
                ForEach(Array(tickers.enumerated()), id: \.offset) { idx, ticker in
                    HStack(spacing: 4) {
                        Circle()
                            .fill(colors[min(idx, colors.count - 1)])
                            .frame(width: 6, height: 6)
                        Text(ticker)
                            .font(.system(size: 11, weight: .semibold, design: .monospaced))
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal)
    }
}

// MARK: - Ripple Card

struct RippleCardView: View {
    let result: RippleResult
    let catalyst: Catalyst
    let histories: [String: [HistoryPoint]]
    let isExpanded: Bool
    let onTap: () -> Void

    var verdictColor: Color {
        switch result.verdict {
        case .confirmed: return .green
        case .forming:   return .orange
        case .failed:    return .red
        case .watching:  return .blue
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header row
            Button(action: onTap) {
                HStack {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(result.rippleTicker)
                            .font(.system(size: 15, weight: .bold, design: .monospaced))
                        Text(result.rippleDescription)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()

                    VStack(alignment: .trailing, spacing: 4) {
                        VerdictBadge(verdict: result.verdict)
                        SparklineView(
                            data: RippleEngine.normalize(
                                history: histories[result.rippleTicker] ?? [],
                                from: histories[result.rippleTicker]?.sorted { $0.date < $1.date }.first?.date
                            ),
                            color: verdictColor,
                            showArea: true,
                            eventDate: catalyst.eventDate,
                            height: 30
                        )
                        .frame(width: 80)
                    }
                }
                .padding(12)
            }
            .foregroundStyle(.primary)

            // Stats row
            HStack(spacing: 12) {
                StatMini(label: "Pre-event", value: String(format: "%+.1f%%", result.preEventChange),
                         color: result.preEventChange >= 0 ? .green : .red)
                StatMini(label: "Post-event", value: String(format: "%+.1f%%", result.postEventChange),
                         color: result.postEventChange >= 0 ? .green : .red)
                Spacer()
                Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 12)
            .padding(.bottom, 12)

            // Expanded: dual chart + explanation
            if isExpanded {
                Divider()
                VStack(alignment: .leading, spacing: 10) {
                    Text("CATALYST vs RIPPLE")
                        .font(.system(size: 9, weight: .semibold, design: .monospaced))
                        .foregroundStyle(.secondary)
                        .tracking(1)

                    // Dual-line chart
                    Chart {
                        let catNorm = RippleEngine.normalize(
                            history: histories[result.catalystTicker] ?? [],
                            from: histories[result.catalystTicker]?.sorted { $0.date < $1.date }.first?.date
                        )
                        let ripNorm = RippleEngine.normalize(
                            history: histories[result.rippleTicker] ?? [],
                            from: histories[result.rippleTicker]?.sorted { $0.date < $1.date }.first?.date
                        )
                        ForEach(Array(catNorm.enumerated()), id: \.offset) { _, pt in
                            LineMark(x: .value("Date", pt.date), y: .value("Chg", pt.pctChange), series: .value("T", result.catalystTicker))
                                .foregroundStyle(Color.orange)
                                .lineStyle(StrokeStyle(lineWidth: 2))
                        }
                        ForEach(Array(ripNorm.enumerated()), id: \.offset) { _, pt in
                            LineMark(x: .value("Date", pt.date), y: .value("Chg", pt.pctChange), series: .value("T", result.rippleTicker))
                                .foregroundStyle(verdictColor)
                                .lineStyle(StrokeStyle(lineWidth: 2))
                        }
                        RuleMark(x: .value("Event", catalyst.eventDate))
                            .foregroundStyle(Color.orange.opacity(0.5))
                            .lineStyle(StrokeStyle(dash: [2, 2]))
                    }
                    .chartYAxis { AxisMarks(format: .percent.scale(0.01)) }
                    .frame(height: 120)

                    // Verdict explanation
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: result.verdict.icon)
                            .foregroundStyle(verdictColor)
                        Text(result.verdictExplanation)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .padding(10)
                    .background(verdictColor.opacity(0.08))
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                }
                .padding(12)
            }
        }
        .background(Color(.systemGray6))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }
}

// MARK: - Stat Mini

struct StatMini: View {
    let label: String; let value: String; var color: Color = .primary
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(.system(size: 9, design: .monospaced)).foregroundStyle(.tertiary).textCase(.uppercase)
            Text(value)
                .font(.system(size: 12, weight: .bold, design: .monospaced)).foregroundStyle(color)
        }
    }
}
