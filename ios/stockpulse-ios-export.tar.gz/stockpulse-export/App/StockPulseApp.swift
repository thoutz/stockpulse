// App/StockPulseApp.swift
import SwiftUI
import SwiftData

@main
struct StockPulseApp: App {
    var body: some Scene {
        WindowGroup {
            RootTabView()
        }
    }
}

// Views/RootTabView.swift
import SwiftUI

struct RootTabView: View {
    @State private var vm = RippleViewModel()

    var body: some View {
        TabView {
            RippleTrackerView()
                .tabItem { Label("Ripple", systemImage: "waveform.path") }

            WatchlistView()
                .tabItem { Label("Watchlist", systemImage: "list.bullet.rectangle") }

            TrendCompareView()
                .tabItem { Label("Trends", systemImage: "chart.line.uptrend.xyaxis") }

            AIAnalystView()
                .tabItem { Label("AI", systemImage: "brain.head.profile") }
        }
        .environment(vm)
        .preferredColorScheme(.dark)
        .task { await vm.loadAll() }
        .tint(.blue)
    }
}
